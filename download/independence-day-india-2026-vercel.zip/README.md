# 🇮🇳 Independence Day 2026 — India

A premium, cinematic, immersive Independence Day experience for India built with Next.js 16, TypeScript, Tailwind CSS 4, and Framer Motion.

> **Tagline:** _A journey from sacrifice to freedom, from freedom to progress._

---

## ✨ Features

- **Cinematic loading screen** — Animated Ashoka Chakra → "भारत" → "INDIA" reveal
- **Hero section** — Waving Tiranga flag (realistic cloth physics), tricolor particle field, rotating chakra backdrop
- **The Night Before Freedom** — Scroll-driven storytelling from 14 Aug 1947 evening → Midnight → 15 Aug 1947 dawn, with background color transitioning saffron → midnight blue → dawn green
- **Freedom Fighters** — 10 interactive cards (Gandhi, Bose, Bhagat Singh, Azad, Patel, Nehru, Lakshmibai, Naidu, Mangal Pandey, Ambedkar) with biographical modals
- **India Through Time** — Cinematic vertical timeline 1857→1947 with 7 milestone events
- **India's Journey** — 9 progress cards with animated counters and accurate verifiable statistics
- **Interactive India Map** — Hoverable SVG map with 6 cultural regions
- **Interactive Quiz** — 12 questions on India's freedom struggle with scoring
- **Finale** — Canvas-based fireworks, tricolor confetti, "JAI HIND" reveal with "Celebrate Again" replay
- **Synthesized patriotic music** — Web Audio API drone + tabla + flute (no audio files needed)
- **Easter eggs** — Konami code, type "jaihind", triple-click headings
- **PWA** — Installable, standalone display, offline-friendly shell
- **Accessibility** — Semantic HTML, keyboard nav, focus states, `prefers-reduced-motion` support
- **Mobile-first responsive** — Hamburger slide-out menu, touch-friendly 44px+ targets

---

## 🚀 Deploy to Vercel

### Option A — One-Click Deploy (recommended)

1. Unzip this folder.
2. Go to [vercel.com/new](https://vercel.com/new) and sign in with GitHub/GitLab/Bitbucket/email.
3. Drag and drop the unzipped folder onto the Vercel dashboard.
4. Vercel will auto-detect Next.js — click **Deploy**.
5. Your site is live in ~2 minutes at `https://<your-project>.vercel.app`.

### Option B — Via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Navigate to the unzipped folder
cd independence-day-india-2026

# Deploy
vercel

# Deploy to production
vercel --prod
```

### Option C — Via Git

1. Push the unzipped folder to a GitHub/GitLab/Bitbucket repo.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Vercel auto-detects Next.js — just click **Deploy**.
4. Every `git push` to `main` will auto-deploy.

---

## 🛠 Local Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Open http://localhost:3000
```

### Build for production

```bash
npm run build
npm start
```

---

## 📦 Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 |
| UI Components | shadcn/ui (New York style) |
| Animations | Framer Motion |
| Particles/Fireworks | HTML5 Canvas |
| Music | Web Audio API (synthesized, no files) |
| Fonts | Cinzel, Inter, Tiro Devanagari Hindi (Google Fonts) |
| Icons | Lucide React |

---

## 📁 Project Structure

```
.
├── public/
│   ├── icon.svg              # PWA icon (Ashoka Chakra)
│   ├── manifest.json         # PWA web manifest
│   ├── logo.svg
│   └── robots.txt
├── src/
│   ├── app/
│   │   ├── globals.css       # Tiranga theme tokens + Indian ornamental CSS
│   │   ├── layout.tsx        # Fonts, metadata, PWA manifest
│   │   └── page.tsx          # Main page orchestration
│   └── components/
│       ├── india/
│       │   ├── AshokaChakra.tsx              # 24-spoke SVG chakra
│       │   ├── WavingFlag.tsx                # Realistic cloth-physics flag
│       │   ├── ParticleCanvas.tsx            # Tricolor particle field
│       │   ├── LoadingScreen.tsx
│       │   ├── HeroSection.tsx
│       │   ├── Navbar.tsx                    # Sticky glass nav + mobile menu
│       │   ├── NightBeforeFreedomSection.tsx # Scroll-driven storytelling
│       │   ├── FreedomFightersSection.tsx    # Cards + modal
│       │   ├── TimelineSection.tsx           # 1857→1947 timeline
│       │   ├── IndiaJourneySection.tsx       # Animated counters
│       │   ├── InteractiveMapSection.tsx     # Hoverable India map
│       │   ├── QuizSection.tsx               # 12-question quiz
│       │   ├── FinaleSection.tsx             # Fireworks + JAI HIND
│       │   ├── MusicController.tsx           # Web Audio synth music
│       │   ├── EasterEggs.tsx                # Hidden interactions
│       │   └── data/
│       │       ├── freedomFighters.ts        # 10 fighters data
│       │       └── timeline.ts               # 7 timeline events
│       └── ui/                # shadcn/ui primitives
├── next.config.ts
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── vercel.json
└── README.md
```

---

## 🎨 Theme

The visual identity uses the Tiranga color palette plus traditional accents:

| Token | Hex | Usage |
|---|---|---|
| Saffron | `#FF9933` | Top stripe, primary accent |
| White | `#FFFFFF` | Middle stripe, body text |
| India Green | `#138808` | Bottom stripe, success |
| Chakra Blue | `#000080` | Ashoka Chakra, deep accent |
| Gold | `#D4AF37` | Ornamental accents, dividers |
| Midnight | `#060818` | Background base |

---

## 🥚 Easter Eggs

| Trigger | Effect |
|---|---|
| Konami code: `↑ ↑ ↓ ↓ ← → ← → B A` | Special JAI HIND celebration burst |
| Type `jaihind` anywhere | Triggers fireworks celebration |
| Triple-click any heading | Reveals a hidden patriotic quote |

---

## ♿ Accessibility

- Semantic HTML5 (`<main>`, `<header>`, `<nav>`, `<section>`, `<article>`)
- ARIA labels on all interactive elements
- Keyboard navigation (Tab, Enter, Escape)
- Visible gold focus rings
- `prefers-reduced-motion` respected — animations disabled, static frames shown
- Touch targets ≥ 44px on mobile
- Color contrast WCAG AA compliant for body text

---

## ⚡ Performance

- `requestAnimationFrame`-driven canvas (particles, fireworks, flag wave)
- Particle count capped (max 110 per canvas, density-aware)
- DPR-aware canvas (capped at 2x for perf)
- CSS animations preferred over JS where possible
- Google Fonts with `display: swap`
- No external audio files — music synthesized in-browser
- Reduced-motion users get static visuals

---

## 📜 License

This is a tribute project. Feel free to use, modify, and share. 🇮🇳

---

**Vande Mataram · सत्यमेव जयते · Jai Hind 🇮🇳**

_Happy Independence Day — 15 August 2026_
